Save genuine screenshots of your own Java execution here. Suggested names: Task03_Output.png, Task08_Output.png, Task11_Output.png, Task12_Output.png.
